import "./App.css"

export default function App() {
  return(
    <div classname = "page">
      <div classname = "award">
        Great Taste Award Winner 2026
      </div>
      <div classname = "brand">
      <h1>Tom Hixson</h1>
      </div>
      <div classname = "products">
      <img classname = "product-img" src = "https://th.bing.com/th/id/OIP.MZ87A8q6rBtd5CiuB0yPLwHaFB?w=229&h=180&c=7&r=0&o=7&dpr=1.5&pid=1.7&rm=3"></img>
        <h2>USDA St Louis Pork Ribs</h2>
      </div>
      <div classname = "price">£15.99</div>
      <div classname = "product-info">
      <div classname = "info-box">
        From 1.3 Kg
      </div>
        <div classname = "info-box">
        Serves 6-7
        </div>
      </div>
      <div classname = "buttons">
      <button>Buy Now</button>
      <button>Add To Cart</button>
      </div>
    </div>
  )
}