
# STEP 1 — App.jsx

1. Import the CSS file called `App.css`.

2. Create a React component called `App`.

3. Inside the `App` component, create a `return` statement.

4. Inside the return statement, create one main `<div>`.

5. Give the main `<div>` the class name `page`.

6. Inside the `page` div, create another `<div>` for the award banner.

7. Give the award banner the class name `award`.

8. Inside the award banner, display the text:
   `Great Taste Award Winner 2026`

9. After the award banner, create another `<div>` for the brand section.

10. Give the brand section the class name `brand`.

11. Inside the brand section, create an `<h1>` element.

12. Display `Tom Hixson` inside the `<h1>`.

13. After the brand section, create a `<div>` for the complete product section.

14. Give the product section the class name `product`.

15. Inside the product section, create an `<img>` element.

16. Set the image source to `/ribs.jpg`.

17. Give the image an `alt` attribute describing the product.

18. Give the image the class name `product-image`.

19. Under the image, create an `<h2>` element.

20. Display `USDA St Louis Pork Ribs` inside the `<h2>`.

21. Under the product name, create a `<div>` for the price.

22. Give the price div the class name `price`.

23. Display `£15.99` inside the price div.

24. Under the price, create a `<div>` for the product information.

25. Give this div the class name `product-info`.

26. Inside `product-info`, create a `<div>` for the weight information.

27. Give this div the class name `info-box`.

28. Display `From 1.3 Kg` inside it.

29. Create another `<div>` inside `product-info`.

30. Give the second div the class name `info-box`.

31. Display `Serves 6-7` inside the second information box.

32. Under `product-info`, create a `<div>` for the two buttons.

33. Give this div the class name `buttons`.

34. Inside `buttons`, create a `<button>`.

35. Display `Buy Now` inside the first button.

36. Create a second `<button>`.

37. Display `Add To Cart` inside the second button.

38. Close all opened elements correctly.

39. Export the `App` component as the default export.


---

# STEP 2 — App.css

## General Page Styling

40. Select every element using the universal selector.

41. Set `box-sizing` so padding and borders are included in the element's total width.

42. Select the `body`.

43. Remove the default body margin.

44. Set the font family to Arial or another clean sans-serif font.

45. Set the body background colour to light grey.

---

# Main Product Card

46. Select `.page`.

47. Set its width to approximately `318px`.

48. Centre the card horizontally using margin.

49. Give the card a white background.

---

# Award Banner

50. Select `.award`.

51. Give the award banner a height of approximately `64px`.

52. Set its background colour to a light beige colour.

53. Use Flexbox.

54. Centre the text horizontally.

55. Centre the text vertically.

56. Set the text colour to white.

57. Make the text bold.

58. Set the font size to approximately `15px`.

59. Add some letter spacing.

---

# Brand Section

60. Select `.brand`.

61. Give the brand section a height of approximately `110px`.

62. Set the background colour to dark navy blue.

63. Use Flexbox.

64. Vertically centre the contents.

65. Select the `<h1>` inside `.brand`.

66. Move the brand name slightly to the right using left margin.

67. Make the brand name white.

68. Set the font size to approximately `34px`.

69. Make the font lighter.

70. Make the brand name italic.

---

# Product Section

71. Select `.product`.

72. Add internal spacing using padding.

73. Centre-align the text inside the product section.

---

# Product Image

74. Select `.product-image`.

75. Set the image width to approximately `195px`.

76. Set the image height to approximately `155px`.

77. Make the image fit neatly inside its defined dimensions using `object-fit`.
78. Give the image rounded corners.

79. Make the image a block element.

80. Centre the image horizontally.

81. Add some space below the image.

---

# Product Name

82. Select the `<h2>` inside `.product`.

83. Remove its default margin.

84. Set the font size to approximately `19px`.

85. Make the text bold.

86. Add a small amount of letter spacing.

---

# Price

87. Select `.price`.

88. Make the price behave like a small box around the text.

89. Add a small top margin.

90. Add padding around the price.

91. Give the price a beige background.

92. Give the price slightly rounded corners.

93. Set the font size to approximately `19px`.

94. Make the price bold.

---

# Product Information

95. Select `.product-info`.

96. Add some space above the information section.

97. Add vertical padding.

98. Add a thin border at the top.

99. Add a thin border at the bottom.

100. Use Flexbox.

101. Place the two information boxes at opposite sides using `justify-content`.

102. Select `.info-box`.

103. Give each information box a light blue background.

104. Add padding around the text.

105. Give the boxes slightly rounded corners.

106. Make the information text bold.

107. Set an appropriate font size.

---

# Buttons Container

108. Select `.buttons`.

109. Use Flexbox.

110. Place the two buttons at opposite sides.

111. Add space above the buttons.

---

# Buttons

112. Select all buttons inside `.buttons`.

113. Set the width of each button to approximately `122px`.

114. Set the height of each button to approximately `73px`.

115. Remove the default button border.

116. Give the buttons slightly rounded corners.

117. Set the button background colour to the same dark navy blue.

118. Set the button text colour to white.

119. Set the button font size to approximately `17px`.

120. Make the button text semi-bold.

121. Change the cursor to a pointer when hovering over the buttons.

---

# Button Hover Effect

122. Create a `:hover` state for the buttons.

123. Change the button background colour when the mouse is over it.

124. Move the button slightly upward when hovered using `transform`.

---

# STEP 3 — Image Setup

125. Create a `public` folder if it does not already exist.

126. Place the product image inside the `public` folder.

127. Rename the image to `ribs.jpg`.

128. Make sure the image path used in JSX starts with `/`.

129. Run the React project and check that the image appears.

---

# STEP 4 — Final Check

130. Make sure the award banner appears at the top.

131. Make sure the dark blue brand section appears below it.

132. Make sure `Tom Hixson` appears inside the brand section.

133. Make sure the product image appears below the brand section.

134. Make sure the product name is centred.

135. Make sure the price appears inside a beige box.

136. Make sure `From 1.3 Kg` appears on the left.

137. Make sure `Serves 6-7` appears on the right.

138. Make sure `Buy Now` and `Add To Cart` appear side-by-side.

139. Check that the buttons have the correct dark blue colour.

140. Hover over each button and check the hover effect.

141. Compare the final result with the reference image.